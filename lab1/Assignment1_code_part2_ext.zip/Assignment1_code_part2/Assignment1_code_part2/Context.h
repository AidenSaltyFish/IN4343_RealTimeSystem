#ifndef __Context_h
#define __Context_h

/*
 * Context interface
 *
 * Boris Blokland, 15-1-2019
 */

void ContextSwitch();
void ResumeContext();

#endif
